<?php

class User {
    protected $email;
    protected $username;
    public function register(){
    // register function here
    }
    public function make_tweet($tweet){
    // make tweet function here
    }
    public function logout(){
        // logout function here
    }
}
?>