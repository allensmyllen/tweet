<?php
session_start();
require_once 'database/dbConfig.php';
$userToView = $_SESSION['userToView'];
$sql = "SELECT * FROM users WHERE username='$userToView'";
$result = $Conn->query($sql);
while($row = $result->fetch_assoc()){
    $username = $row['username'];
   
   
    $course = $row['course'];
   
    $email = $row['email'];
    $reg_date = $row['reg_date'];
    $proPix = $row['profile_picture'];
} 
echo $username.$course.$birthday.$gender.$phone.$email.$reg_date.$proPix;
?>
