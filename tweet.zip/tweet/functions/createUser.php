<?php
        $txtPassword =  $txtEmail = "";
        $txtPasswordErr =  $txtEmailErr = "";
        $passwordIsset =  $emailIsset = false; 

        if ($_SERVER['REQUEST_METHOD'] == "POST"){

          
            $txtUsername = formatData($_POST['txtUsername']);
        

            //Check availiabilty of Username;
            if (strlen($_POST['txtPassword']) < 6){
                $txtPasswordErr = "Password must be atleast 6 characters long";
            }else{
                $txtConPasswordErr = "";
                $passwordIsset = true;
                $txtPassword = formatData($_POST['txtPassword']);

           
            }
            if (!filter_var($_POST['txtEmail'], FILTER_VALIDATE_EMAIL)){
                $txtEmailErr = "Invalid Email Address";
            } else{
                //   echo "<script>alert('I am Okay now!')</script>";
                $txtEmailErr = "";
                $emailIsset = true;
                $txtEmail = formatData($_POST['txtEmail']);
            }

            if ($passwordIsset == true  && $emailIsset == true){
                echo "<script>alert('Registration Was SuccessFul, please login now...  $txtUsername, $txtPassword, $txtEmail')</script>";
                $txtFirstname = $txtOthernames = $txtUsername = $txtPassword =  $txtEmail = "";
                $txtPasswordErr =  $txtEmailErr = "";

            }
        }

        function formatData($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
