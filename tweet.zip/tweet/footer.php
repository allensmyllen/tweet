<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-push-3 footerBlock" style="padding:0px;">
                <div class="container-fluid" id="about">
                    <div class="row" style="background-image:url(Img/naturalblack.png)">
                        <div class="col-md-4 col-xs-2">
                            <i class="fa fa-twitter aboutIcon"></i>
                        </div>
                        <div class="col-md-8 col-xs-10" style="padding-left:30px;padding-bottom:0px;">
                            <br>
                            <p>DS Poly No.1 Twitter</p>
                            <p>Tell All :</p>
                            <p><a href="whatsapp://send?text=Guys... Check Out this new Website: DSPolytweets.com, My username is: <?php echo $_SESSION['username']?> !" data-action="share/whatsapp/share"><span class="fa fa-whatsapp"></span> Share via Whatsapp</a></p>
                            
                            <p> <a href="http://www.facebook.com/sharer.php?u=http://Dspolytweet.comxa.com" target="_blank"><span class="fa fa-facebook"></span> Share via Facebook</a></p>
                            
                            <p class="aboutInfo"><span class="glyphicon glyphicon-phone-alt"></span> <b>HelpDesk:</b> <a href="mailto:RitcheyDev@gmail.com">help@dstweets.com</a></p>

                            <p>&copy; Allen Smyllen 2019</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


</footer>
